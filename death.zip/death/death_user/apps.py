from django.apps import AppConfig


class DeathuserConfig(AppConfig):
    name = 'death_user'
